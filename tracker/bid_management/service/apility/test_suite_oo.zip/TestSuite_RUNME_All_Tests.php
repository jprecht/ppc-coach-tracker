<?php
	require_once('apility.php');
	$apilityUser = new APIlityUser();
  // in case of sandbox usage, make sure the clients get created
  $apilityUser->getManagersClientAccounts();      	

	echo "<h1>APIlity Test Suite (API " . API_VERSION . ")</h1>\n";
	echo "<hr>";

	require_once('TestSuite_Campaign.php');
	require_once('TestSuite_AdGroup.php');
	require_once('TestSuite_Criterion.php');
	require_once('TestSuite_Ad.php');
	require_once('TestSuite_Report.php');
	require_once('TestSuite_TrafficEstimate.php');
	require_once('TestSuite_KeywordTool.php');
	require_once('TestSuite_SiteSuggestion.php');
?>